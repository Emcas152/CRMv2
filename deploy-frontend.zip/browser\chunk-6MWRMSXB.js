import{Z as n}from"./chunk-62TOQIDI.js";var t=new n("API_BASE_URL");export{t as a};
